<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of System_library
 *
 * @author noelyhero
 */
class App_library {
    //put your code here

    protected $app,$news;
    private $admin;

    public function __construct() {
        $this->app =& get_instance();
		$this->app->load->model(array('app_model'=>'model'));
        $this->admin =& get_instance();
        $this->news =& get_instance();
    }

   /** Registration validations */
   
   public function validate_news(){
        $this->news->load->library('form_validation');
        $data['blog_image'] = $this->news->input->post('blog_image');
        $data['blog_title'] = $this->news->input->post('blog_title');
        $data['blog_desc'] = $this->news->input->post('blog_desc');
        $this->news->form_validation->set_data($data);
        $rules = array(

            array(
                'field' => 'blog_title',
                'label' => 'Blog Title ',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'Please fill %s.',
                ),
            ),
            array(
                'field' => 'blog_desc',
                'label' => 'Blog description',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'Please fill %s.',
                ),
            ),
        );

        $this->news->form_validation->set_rules($rules);
        if ($this->news->form_validation->run() == TRUE)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
  

  public function action_status($flag=NULL,$message=NULL) {
         $this->app->load->library('form_validation');
        switch ($flag) {
            case 'success':
                $status['flag'] = TRUE; $status['status'] = 'Success';
                $status['class'] = 'alert-success';  $status['message'] = $message;
                break;
            case 'fail':
                $status['flag'] = TRUE; $status['status'] = 'Failed';
                $status['class'] = 'alert-danger';  $status['message'] = $message;
                break;
            default:
                $status['flag'] = FALSE;
                $status['class'] = 'alert-danger';$status['message'] = 'Undefined';
                break;
        }
        $this->app->load->vars(['status'=>$status]);
    }

  public function uploadImage($path) {
        $config['upload_path']          = $path;
        $config['file_ext_tolower']     = TRUE;
        $config['encrypt_name']         = TRUE;
        $config['allowed_types']        = 'jpeg|jpg|png';

        $this->app->load->library('upload', $config);
        if ( ! $this->app->upload->do_upload('file')) {
            $data['data'] = $this->app->upload->display_errors();
            $data['status'] = FALSE;
        }
        else {
            $data['data'] = $this->app->upload->data();
            $data['status'] = TRUE;
        }
        $data['path'] = $path;
        return $data;
    }

  public function uploadFile($path) {
                 $config['upload_path']          = $path;
                 $config['file_ext_tolower']     = TRUE;
                 $config['encrypt_name']         = TRUE;
                 $config['allowed_types']        = 'jpeg|jpg|png|xls|xlsx|ods';

                 $this->app->load->library('upload', $config);

                  if ( ! $this->app->upload->do_upload('file')) {
                         $data['data'] = $this->app->upload->display_errors();
                         $data['status'] = FALSE;
                      }
                     else {
                         $data['data'] = $this->app->upload->data();
                         $data['status'] = TRUE;
                     }
                     $data['path'] = $path;
             return $data;
     }

  public function uploadFilePdf($path) {
      $config['upload_path']          = $path;
      $config['file_ext_tolower']     = TRUE;
      $config['encrypt_name']         = TRUE;
      $config['allowed_types']        = 'pdf';

      $this->app->load->library('upload', $config);
       if ( ! $this->app->upload->do_upload('file')) {
              $data['data'] = $this->app->upload->display_errors();
              $data['status'] = FALSE;
           }
          else {
              $data['data'] = $this->app->upload->data();
              $data['status'] = TRUE;
          }
          $data['path'] = $path;
  return $data;
      }

    public function do_upload(){
        $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png';

        $this->app->load->library('upload', $config);

        if ( ! $this->app->upload->do_upload('userfile'))
        {
            return FALSE;
        }
        else
        {
            return $this->app->upload->data();
        }
    }

}
