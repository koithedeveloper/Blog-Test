<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function is_student_course($student,$course){
	  $obj  =& get_instance();
		$obj->db->where('cs_student_key',$student);
		$obj->db->where('cs_course_key',$course);
		$result = $obj->db->get('courses_students');
		return $result->num_rows();
}
		/**
	     * Get an unused ID for user creation
	     *
	     * @return  int between 1200 and 4294967295
	     */
	    function unique_user_id()
	    {
        $obj  =& get_instance();

	        // Create a random user id between 1200 and 4294967295
	        $random_unique_int = 2147483648 + mt_rand( -2147482448, 2147483647 );

	        // Make sure the random user_id isn't already in use
	        $query = $obj->db->where( 'user_id', $random_unique_int )
	            ->get_where( 'users' );

	        if( $query->num_rows() > 0 )
	        {
	            $query->free_result();

	            // If the random user_id is already in use, try again
	            return unique_user_id();
	        }

	        return $random_unique_int;
	    }

      /**
         * Get an unused ID for user creation
         *
         * @return  int between 1200 and 4294967295
         */
        function unique_course_key()
        {
          $obj  =& get_instance();

            // Create a random user id between 1200 and 4294967295
            $random_unique_int = 2147483648 + mt_rand( -2147482448, 2147483647 );

            // Make sure the random user_id isn't already in use
            $query = $obj->db->where( 'course_key', $random_unique_int )
                ->get_where( 'courses' );

            if( $query->num_rows() > 0 )
            {
                $query->free_result();

                // If the random user_id is already in use, try again
                return unique_course_key();
            }

            return $random_unique_int;
        }

function admin_primary_menu(){?>
  <h1>Welcom! <?php echo profile()->firstname.' '.profile()->lastname;?></h1>
<ul>
  <li><a href="<?php echo base_url('admin/dashboard');?>">Dashboard</a></li>
  <li><a href="<?php echo base_url('admin/courses');?>">Courses</a></li>
  <li><a href="<?php echo base_url('admin/teachers');?>">Teachers</a></li>
  <li><a href="<?php echo base_url('admin/students');?>">Students</a></li>
  <li><a href="<?php echo base_url('logout');?>">Logout</a></li>
</ul>
<?php }

function newsLatest(){
    $helper =&  get_instance();
    $helper->load->model(array("NewsModel"=>"newsModel"));
    return $helper->newsModel->newsLatest();
}

function uploadFilePath($path){
  return base_url().'/uploads/'.$path;
}

function uploadPath($path=''){
	return dirname(APPPATH).'/uploads/'.$path;
}

function admin_students_menu(){?>
<table>
  <tbody>
    <tr>
      <td><a href="<?php echo base_url('admin/students');?>">All Students</a></td>
    </tr>
  </tbody>
</table>
<?php }

function profile(){
    $obj  =& get_instance();
    return $obj->db->where('user_id',$obj->auth_user_id)->get('users')->row();
}
