<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post extends MY_Controller {

     public  $appdata;

    function __construct() {
        parent::__construct();
        $this->appdata['title']= 'Blogs';
        $this->load->model(array(
            'NewsModel'=>'newsModel',
        ));
    } 

	public function index()
	{
		$this->appdata['title'] = 'Add Post';
		 $this->load->helper('form');
        if($this->tokens->match) {
            if($this->app_library->validate_news()){
                $uploadData = $this->app_library->uploadImage(uploadPath('blog_image'));
                if ($uploadData['status']) {
                    $data['blog_image'] = $uploadData['data']['file_name'];
                    $data['blog_title'] = $this->input->post('blog_title',TRUE);
                    $data['blog_desc'] = $this->input->post('blog_desc',TRUE);
					$data['blog_created_at'] = date('Y-m-d H:i:s');

                    if ($this->newsModel->news_create($data)) {
                        $this->app_library->action_status('success', 'successfully posted');
                    } else {
                        $this->app_library->action_status('failed', 'failed to save data');
                    }
                } else {
                    $this->app_library->action_status('fail', $uploadData['data']);
                }
            }else{
                $this->app_library->action_status('fail', validation_errors());
            }
        }
	
		$this->load->vars($this->appdata);
		$this->load->view('add_message');
	}

	
	function details($key='') {
        $this->appdata['title'] = 'Blog details';
        $this->appdata['data'] = $this->newsModel->select_one_news($key);
        $this->load->vars($this->appdata);
        $this->load->view('blog_details');
    }
	
	function modify($key=''){
	$this->load->helper('form');
    $this->appdata['title'] = 'Blog modify';
	if($this->tokens->match) {
            if($this->app_library->validate_news()){
                $uploadData = $this->app_library->uploadImage(uploadPath('blog_image'));
                if ($uploadData['status']) {
                    $datas['blog_image'] = $uploadData['data']['file_name'];
                    $datas['blog_title'] = $this->input->post('blog_title',TRUE);
                    $datas['blog_desc'] = $this->input->post('blog_desc',TRUE);

                    if ($this->newsModel->modify_blog($key,$datas)) {
                        $this->app_library->action_status('success', 'successfully updated');
                    } else {
                        $this->app_library->action_status('failed', 'failed to save data');
                    }
                } else {
                    $this->app_library->action_status('fail', $uploadData['data']);
                }
            }else{
                $this->app_library->action_status('fail', validation_errors());
            }
        }
		
    $this->appdata['data'] = $this->newsModel->select_one_news($key);
    $this->load->vars($this->appdata);
    $this->load->view('blog_modify');
  }
  
  //deleteNews
  public function deleteNews($key){
        $image_path = dirname(APPPATH).'/uploads/blog_image/';
        $query = $this->db->where('blog_id',$key)->from('blogs')->get();

        foreach ($query->result_array() as $record){
            $filename = $image_path . $record['blog_image'];
            if (file_exists($filename)){
                unlink($filename);
            }
        }

        $this->db->where('blog_id',$key);
        $this->db->delete('blogs');
        if($this->db->affected_rows()>0){
            $result['status'] = 'ok';
            $result['message'] = 'Blog Deleted successfully';
        }else{
            $result['status'] = 'no';
            $result['message'] = checkError($this->dbexeption());
        }
        print json_encode($result);

    }
	
}
