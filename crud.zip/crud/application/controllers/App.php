<?php
defined('BASEPATH') OR exit('No direct script access allowed');

Class App extends MY_Controller
{

  public function __construct(){
    parent:: __construct();
  }

  function index(){
    $this->require_min_level(1);
    redirect(base_url($this->auth_role.'/dashboard'));
  }

  function chumbani(){
    $this->load->helper('form');
      // Method should not be directly accessible
      if( $this->uri->uri_string() == 'app/chumbani')
        show_404();

      if( strtolower( $_SERVER['REQUEST_METHOD'] ) == 'post' )
        $this->require_min_level(1);

      $this->setup_login_form();

      $this->load->view('auth/login');

  }

  /**
   * Log out
   */
  public function logout()
  {
    $this->authentication->logout();

    // Set redirect protocol
    $redirect_protocol = USE_SSL ? 'https' : NULL;

    redirect( site_url( LOGIN_PAGE . '?' . AUTH_LOGOUT_PARAM . '=1', $redirect_protocol ) );
  }

  function register()
  {
    $this->pagedata['title'] = 'Registration';
    $this->load->helper('form');
    if($this->tokens->match){
      $data['firstname'] = $this->input->post('firstname',TRUE);
      $data['passwd'] = $this->authentication->hash_passwd($this->input->post('password',TRUE));
      $data['username'] = $this->input->post('username',TRUE);
      $data['email'] = $this->input->post('email',TRUE);
      $data['middlename'] = $this->input->post('middlename',TRUE);
      $data['lastname'] = $this->input->post('lastname',TRUE);
      $data['user_id'] = unique_user_id();
      $data['auth_level'] = 1;
      $data['created_at'] = date('Y-m-d H:i:s');
      $courses = $this->input->post('courses');
      $this->app_model->register_student($data,$courses);
    }
    $this->pagedata['courses'] = $this->app_model->courses_all();
    $this->load->vars($this->pagedata);
    $this->load->view('auth/register');
  }
}
