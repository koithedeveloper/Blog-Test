<?php
defined('BASEPATH') OR exit('No direct script access allowed');

Class Dashboard extends MY_Controller
{

  public function __construct(){
    parent:: __construct();
    $this->require_role('admin');
  }

  function index()
  {
    $this->load->view('admin/dashboard');
  }

}
