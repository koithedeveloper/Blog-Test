<?php
defined('BASEPATH') OR exit('No direct script access allowed');

Class Courses extends MY_Controller
{
  public $pagedata;

  public function __construct(){
    parent:: __construct();
    $this->require_role('admin');
    $this->pagedata['title'] = 'Courses';
  }

  function index()
  {
    $this->pagedata['courses'] = $this->app_model->courses_all();
    $this->load->vars($this->pagedata);
    $this->load->view('admin/courses');
  }

  function create()
  {
    $this->pagedata['title'] = 'Create Course';
    $this->load->helper('form');
    if($this->tokens->match){
      $data['course_name'] = $this->input->post('course_name',TRUE);
      $data['course_duration'] = $this->input->post('course_duration',TRUE);
      $data['course_key'] = unique_course_key();
      $this->app_model->courses_create($data);
    }
    $this->pagedata['courses'] = $this->app_model->courses_all();
    $this->load->vars($this->pagedata);
    $this->load->view('admin/courses_create');
  }

  function details($key='')
  {
    $this->pagedata['title'] = 'Course details';
    $this->pagedata['course'] = $this->app_model->courses_details($key);
    $this->pagedata['students'] = $this->app_model->courses_students($key);
    $this->load->vars($this->pagedata);
    $this->load->view('admin/courses_details');
  }

}
