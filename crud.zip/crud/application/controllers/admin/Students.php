<?php
defined('BASEPATH') OR exit('No direct script access allowed');

Class Students extends MY_Controller
{
  public $pagedata;

  public function __construct(){
    parent:: __construct();
    $this->require_role('admin');
    $this->pagedata['title'] = 'Students';
  }

  function index()
  {
    $this->pagedata['students'] = $this->app_model->students_all();
    $this->load->vars($this->pagedata);
    $this->load->view('admin/students');
  }

  function create()
  {
    $this->pagedata['title'] = 'Create Course';
    $this->load->helper('form');
    if($this->tokens->match){
      $data['course_name'] = $this->input->post('course_name',TRUE);
      $data['course_duration'] = $this->input->post('course_duration',TRUE);
      $data['course_key'] = unique_course_key();
      $this->app_model->courses_create($data);
    }
    $this->pagedata['courses'] = $this->app_model->courses_all();
    $this->load->vars($this->pagedata);
    $this->load->view('admin/courses_create');
  }

  function modify($key='')
  {
    if($this->tokens->match){
      $data['firstname'] = $this->input->post('firstname',TRUE);
      $data['email'] = $this->input->post('email',TRUE);
      $data['middlename'] = $this->input->post('middlename',TRUE);
      $data['lastname'] = $this->input->post('lastname',TRUE);
      $courses = $this->input->post('courses');
      $this->app_model->modify_student($key,$data,$courses);
    }
    $this->load->helper('form');
    $this->pagedata['courses'] = $this->app_model->courses_all();
    $this->pagedata['title'] = 'Student modify';
    $this->pagedata['student'] = $this->app_model->student_details($key);
    $this->load->vars($this->pagedata);
    $this->load->view('admin/student_modify');
  }

  function details($key='')
  {
    $this->pagedata['title'] = 'Student Courses';
    $this->pagedata['courses'] = $this->app_model->student_courses($key);
    $this->pagedata['student'] = profile($key);
    $this->load->vars($this->pagedata);
    $this->load->view('admin/student_details');
  }

}
