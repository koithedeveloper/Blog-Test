<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Dashboard  </title>
  </head>
  <body>
      <?php admin_primary_menu();?>
  </body>
</html>
