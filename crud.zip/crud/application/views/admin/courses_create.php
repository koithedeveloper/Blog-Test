<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Courses  </title>
  </head>
  <body>
      <?php admin_primary_menu();?>
      <br>
      <?php admin_course_menu();?>
      <br/>
      <?php echo form_open(current_url());?>
      <input name="course_name" placeholder="Course name" />
      <input name="course_duration" placeholder="Course duration" />
      <button type="submit" name="button">Submit</button>
      <?php echo form_close();?>
      <hr/>
      <table border="1" cellpadding="3">
        <thead>
          <tr>
            <th>S/N</th>
            <th>Course Name</th>
            <th>Duration</th>
            <th colspan="3">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php  if(! empty($courses)){
            foreach ($courses as $key => $koz) {  $key++;?>
              <tr>
                <td><?php echo $key;?></td>
                <td><?php echo $koz['course_name'];?></td>
                <td><?php echo $koz['course_duration'];?></td>
                <th><a href="<?php echo base_url('admin/courses/details/'.$koz['course_key']);?>">view</a></th>
                <th><a href="<?php echo base_url('admin/courses/modify/'.$koz['course_key']);?>">edit</a></th>
                <th><a href="javascript:(0);">delete</a></th>
              </tr>
            <?php }
          } ?>
        </tbody>
      </table>
  </body>
</html>
