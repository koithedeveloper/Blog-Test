<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Students</title>
  </head>
  <body>
      <?php admin_primary_menu();?>
      <br>
      <?php admin_students_menu();?>
      <br/>
      <?php echo form_open(current_url());?>
      <input name="firstname" value="<?php echo $student->firstname;?>"  placeholder="firstname" /><br/>
      <input name="middlename"  value="<?php echo $student->middlename;?>" placeholder="middlename" /><br/>
      <input name="lastname" value="<?php echo $student->lastname;?>" placeholder="lastname" /><br/>
      <input name="email" value="<?php echo $student->email;?>" type="email" placeholder="email" /><br/>
      <select name="courses[]" multiple >
        <?php foreach ($courses as $key => $va) {?>
           <option  <?php if(is_student_course($student->user_id,$va['course_key'])) echo 'selected';?> value="<?php echo $va['course_key'];?>"><?php echo $va['course_name'];?></option>
        <?php } ?>
      </select>
      <button type="submit">Register</button>
      <?php echo form_close();?>
      <br/>
      <table border="1" cellpadding="3">
        <thead>
          <tr>
            <th>S/N</th>
            <th>Student Name</th>
            <th colspan="3">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php  if(! empty($students)){
            foreach ($students as $key => $koz) {  $key++;?>
            <tr>
              <td><?php echo $key;?></td>
              <td><?php echo $koz['firstname'].' '.$koz['lastname'];?></td>
              <th><a href="<?php echo base_url('admin/students/details/'.$koz['user_id']);?>">view</a></th>
              <th><a href="<?php echo base_url('admin/students/modify/'.$koz['user_id']);?>">edit</a></th>
              <th><a href="javascript:(0);">delete</a></th>
            </tr>
            <?php }
          } ?>
        </tbody>
      </table>
  </body>
</html>
