<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Students</title>
  </head>
  <body>
      <?php admin_primary_menu();?>
      <br>
      <?php admin_students_menu();?>
      <br/>
      <table border="1" cellpadding="3">
        <thead>
          <tr>
            <th>S/N</th>
            <th>Student Name</th>
            <th colspan="3">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php  if(! empty($students)){
            foreach ($students as $key => $koz) {  $key++;?>
            <tr>
              <td><?php echo $key;?></td>
              <td><?php echo $koz['firstname'].' '.$koz['lastname'];?></td>
              <th><a href="<?php echo base_url('admin/students/details/'.$koz['user_id']);?>">view</a></th>
              <th><a href="<?php echo base_url('admin/students/modify/'.$koz['user_id']);?>">edit</a></th>
              <th><a href="javascript:(0);">delete</a></th>
            </tr>
            <?php }
          } ?>
        </tbody>
      </table>
  </body>
</html>
