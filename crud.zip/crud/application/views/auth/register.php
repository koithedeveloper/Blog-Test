<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
  </head>
  <body>
    <?php echo form_open(current_url());?>
    <input name="firstname"  placeholder="firstname" /><br/>
    <input name="middlename"  placeholder="middlename" /><br/>
    <input name="lastname"  placeholder="lastname" /><br/>
    <input name="email"  type="email" placeholder="email" /><br/>
    <input name="username"  placeholder="username" /><br/>
    <input name="password"  placeholder="Password" /><br/>
    <select name="courses[]" multiple >
      <?php foreach ($courses as $key => $va) {?>
         <option value="<?php echo $va['course_key'];?>"><?php echo $va['course_name'];?></option>
      <?php } ?>
    </select>
    <button type="submit">Register</button>
    <?php echo form_close();?>
  </body>
</html>
