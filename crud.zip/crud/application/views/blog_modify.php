<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>CRUD BLOG</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url('koi');?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--

TemplateMo 546 Sixteen Clothing

https://templatemo.com/tm-546-sixteen-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url('koi');?>/assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo base_url('koi');?>/assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="<?php echo base_url('koi');?>/assets/css/owl.css">

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="<?php echo base_url();?>"><h2>KoiNoe <em>Blog</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url();?>">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <li class="nav-item active">
                <a class="nav-link" href="<?php echo base_url('post');?>">Add Blog</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->




    
    <div class="send-message">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Update Post</h2>
            </div>
          </div>
          <div class="col-md-8">
            <div class="contact-form">
			<?php echo form_open_multipart(current_url());?>
                <div class="row">
				<?php  if(!empty($status['flag'])&& $status==TRUE ):?>
                    <div style="width:100%;" class="alert <?php echo $status['class'];?> alert-rounded">
                        <?php echo $status['message'];?>
                    </div>
                <?php endif;?>
                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <fieldset>
                      <input name="blog_title" type="text" value="<?php echo $data->blog_title;?>" class="form-control" id="name" placeholder="Blog Title" required="">
                    </fieldset>
                  </div>
				  <div class="col-lg-12 col-md-12 col-sm-12">
                    <fieldset>
                      <input name="file" type="file" accept="image/*" class="form-control" placeholder="image" required="">
                    </fieldset>
                  </div>
                  
                  <div class="col-lg-12">
                    <fieldset>
                      <textarea name="blog_desc" rows="6" value="<?php echo $data->blog_desc;?>" class="form-control" id="message" placeholder="Blog Description" required=""><?php echo $data->blog_desc;?></textarea>
                    </fieldset>
                  </div>
                  <div class="col-lg-12">
                    <fieldset>
                      <button type="submit" id="form-submit" class="filled-button">Update Post</button>
                    </fieldset>
                  </div>
                </div>
              <?php echo form_close();?>
            </div>
          </div>
          <div class="col-md-4">
            <ul>
			<h2>All Post</h2>
              <?php if(!empty($news = newsLatest())){
                     foreach ($news as $key => $newsData) {?>
			  <li>
                  <a><?php echo $newsData['blog_title'];?></a>
                  <div class="content">
                      <p><?php echo $newsData['blog_desc'];?>.</p>
					  <p>
					  <a href="<?php echo base_url('post/modify/'.$newsData['blog_id']); ?>" data-original-title="Edit"><i class="fa fa-pencil"></i>Update</a> 
					  | <a onclick="newsDetails(<?php echo $newsData['blog_id'];?>)" href="javascript:(0);" data-toggle="tooltip" data-original-title="Delete"> <i class="fa fa-trash"></i> <button class="filled-button">Delete</button></a>
					  </p>
                  </div>
              </li>
			  <?php } } ?>
			  
            </ul>
          </div>
        </div>
      </div>
    </div>


    
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright &copy; <?php echo date('Y');?> KoiNoe Blog Co., Ltd.
            
            - Design: <a rel="nofollow noopener" href="#" target="_blank"></a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url('koi');?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url('koi');?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="<?php echo base_url('koi');?>/assets/js/custom.js"></script>
    <script src="<?php echo base_url('koi');?>/assets/js/owl.js"></script>
    <script src="<?php echo base_url('koi');?>/assets/js/slick.js"></script>
    <script src="<?php echo base_url('koi');?>/assets/js/isotope.js"></script>
    <script src="<?php echo base_url('koi');?>/assets/js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>
