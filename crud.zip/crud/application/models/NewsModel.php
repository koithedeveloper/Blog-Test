<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class NewsModel extends MY_Model {
    public function __construct() {
        parent::__construct();
    }
	
	function news_create($data){
    $this->db->insert('blogs',$data);
    return $this->db->affected_rows();
	}

    public function news() {
        $this->db->order_by('blog_id','DESC');
        $query = $this->db->get( 'blogs');
        return $query->num_rows()>0 ? $query->result_array() : FALSE;
    }

    public function newsLatest() {
        $this->db->order_by('blog_id','DESC');
        $query = $this->db->get( 'blogs','6');
        return $query->num_rows()>0 ? $query->result_array() : FALSE;
    }


    public function select_one_news($key){
        $query = $this->db->select('*')
            ->where('blog_id',$key)
            ->get('blogs');
        return $query->row();
    }
	
	function modify_blog($key,$datas){
	$this->db->trans_start();

	$this->db->where('blog_id',$key);
	$this->db->update('blogs',$datas);
	
	$this->db->trans_complete();

	return $this->db->trans_status();

}
	

}